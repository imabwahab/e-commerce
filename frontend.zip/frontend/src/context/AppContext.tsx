import { createContext, useEffect, useState, type ReactNode } from "react";

interface AppContextType {
  wishList: Record<string, boolean>,
  toggleWishList: (itemId: string) => void;
}

interface AppContextProviderProps {
  children: ReactNode
}

export const AppContext = createContext<AppContextType>({
  wishList: {},
  toggleWishList: () => { }
});

export const AppContextProvider = ({ children }: AppContextProviderProps) => {

  const [wishList, setWishList] = useState<Record<string, boolean>>({});

  const toggleWishList = (itemId: string) => {
    setWishList((prev) => ({
      ...prev, [itemId]: !prev[itemId]
    }))
  };

  useEffect(() => {
    console.log(wishList)
  }, [wishList])

  const value: AppContextType = { wishList, toggleWishList };
  return <AppContext.Provider value={value}>
    {children}
  </AppContext.Provider>
}